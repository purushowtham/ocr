import json,re,html,hashlib,zipfile
from pathlib import Path
from pypdf import PdfReader
O=Path('/private/tmp/ocr2-paper-revised')
d=json.loads((O/'content.json').read_text())
body=d['abstract']+'\n'+'\n'.join(p for _,ps in d['sections'] for p in ps)
def grams(t,n=7):
 w=re.findall(r"[a-z0-9]+",html.unescape(t).lower())
 return set(' '.join(w[i:i+n]) for i in range(len(w)-n+1))
comparison={}
for name in ['model_card','dataset_card','trocr_abstract']:
 text=(O/(name+'.txt')).read_text()
 if name=='trocr_abstract':
  node=re.search(r'<blockquote\b[^>]*class="abstract[^>]*>(.*?)</blockquote>',text,re.S)
  assert node is not None
  text=re.sub(r'<[^>]+>',' ',node.group(1))
 comparison[name]=sorted(grams(body)&grams(text))
m=json.loads(Path('/private/tmp/ocr2-live/reports/corrected_metrics.json').read_text())
required=[]
for key in ['baseline_test','finetuned_test']:
 for field in ['cer','wer','exact_line_accuracy']:
  required.append(f'{m[key][field]*100:.4f}%')
for epoch in m['history']:
 required.extend([f"{epoch['train_loss']:.4f}",f"{epoch['validation']['cer']*100:.4f}%",f"{epoch['validation']['wer']*100:.4f}%"])
required.extend([f"{(m['finetuned_test']['cer']-m['baseline_test']['cer'])*100:.4f}",f"{(m['finetuned_test']['wer']-m['baseline_test']['wer'])*100:.4f}",f"{m['elapsed_seconds']:.1f}"])
assert all(x in body for x in required),[x for x in required if x not in body]
assert m['selected_epoch']==min(m['history'],key=lambda x:x['validation']['cer'])['epoch']==1
assert set(re.findall(r'\[(\d+)\]',body))=={'1','2','3','4','5'}
r=PdfReader(O/'Handwriting_OCR_IEEE_Paper.pdf')
pdftext='\n'.join(p.extract_text() for p in r.pages)
for name in ['Dr. A Malikarjun reddy','B. Purushowtham sai','T. Manavi rao']:
 assert name in pdftext
 assert name in (O/'Handwriting_OCR_IEEE_Paper.tex').read_text()
assert 'Anonymous' not in pdftext
assert len(r.pages)==3
for p in r.pages:assert tuple(map(float,p.mediabox))==(0,0,612,792)
report='''# Manuscript review record

Reviewed: 17 October 2026. Scope: revised IEEE-style handwriting OCR manuscript.

## Authorship and writing

The three names and department details match the request, in the requested order. No institution, postal address, email, or author contribution was invented. All sections, including the abstract and conclusion, were rewritten for clear, direct academic prose. This was editorial assistance, not evidence that the text was written without AI assistance. Authors should review and approve the manuscript and follow the intended venue's disclosure rules.

## Limited originality and attribution checks

This is a limited wording and citation review, not a certified plagiarism report. Turnitin, iThenticate, Copyleaks, and proprietary submission databases were not available. No full manuscript was uploaded to a plagiarism or AI-detection service. No plagiarism percentage or AI-detector result is claimed.

The abstract and eight sections were compared, after lowercase alphanumeric tokenization, with the public Microsoft model card, Teklia dataset card, and the TrOCR paper abstract. Bibliography entries and the manuscript title were excluded from this comparison. The method looked for identical consecutive sequences of seven words. Source snapshots are included in the review evidence archive. Short common phrases, paraphrases, translated copying, images, uncited ideas, and material outside these three texts are not comprehensively assessed by this method.

Sources checked:

- https://huggingface.co/microsoft/trocr-small-handwritten/raw/main/README.md
- https://huggingface.co/datasets/Teklia/IAM-line/raw/main/README.md
- https://arxiv.org/abs/2109.10282 (abstract only for the token comparison)

Seven-word matches by source:
'''
for name,matches in comparison.items():
 report+=f'\n- {name}: {len(matches)} distinct matching sequences.'
 for match in matches:report+=f'\n  - "{match}"'
report+='''

Four additional quoted-phrase web searches were performed:

- "The divergence between training loss and validation error shows why adaptation"
- "Artifact recovery is a further limitation" handwriting
- "This work implements an inspectable English handwriting transcription workflow"
- "The selection rule consequently chooses epoch one"

The returned results did not display exact matches to these quoted phrases. Some results were unrelated or approximate. This is a small search sample, not proof of uniqueness; search indexes omit private, unindexed, and subscription material.

Citations [1]-[5] are present in the text and correspond to the five reference entries. The model card and dataset card support the model purpose and data description; the original TrOCR abstract supports its attribution. The IAM article's title, authors, year, volume, pages, and DOI were checked against its publisher page: https://doi.org/10.1007/s100320200071. The IAM database page timed out in this review; its terms had been consulted during preparation and should be rechecked before redistribution: https://fki.tic.heia-fr.ch/databases/iam-handwriting-database.

## Numerical and scientific checks

'''
report+=f'{len(required)} reported numerical values were checked against corrected_metrics.json; all agree at the displayed rounding. The epoch-one selection also agrees with minimum validation CER. These are consistency checks against the saved record, not an independent rerun of training.\n'
report+='''
- The measured regression is retained: baseline CER/WER 5.9206%/13.6304%; adapted CER/WER 22.8084%/38.1608%.
- Percentage-point increases, epoch losses, validation error rates, and the recorded elapsed interval agree with the saved metrics.
- The manuscript distinguishes line metrics from unmeasured real-page accuracy and identifies prior IAM exposure, unverified writer independence, and the single-seed design.
- The missing corrected checkpoint is disclosed. The earlier recovered checkpoint is not represented as the model responsible for corrected scores.
- No confidence interval, significance result, performance improvement, or new architecture is fabricated.

## Document checks and remaining requirements

The PDF has three US Letter pages with two text columns, the requested author block, numbered sections, equations, one table, one figure, and five references. Every rendered page was visually inspected for clipping, overlap, legibility, and reading flow. Author names were checked in both the PDF and editable source. PDF and LaTeX share the same revised prose.

The editable source uses IEEEtran conference format. A LaTeX compilation test was not available; the supplied PDF was generated separately in an IEEE-style layout. This is not a venue-specific PDF eXpress certification. A target venue has not been specified, so its exact author-block rules, page limit, anonymization requirements, and submission checks remain unverified. Institutional affiliation details have not been supplied.

No document can be guaranteed to pass every plagiarism checker, AI detector, peer review, or submission test. For an institutional similarity report, run the final version through the service supplied by the institution and review flagged passages in context. Do not treat a low similarity number as proof that all citations and claims are correct.
'''
(O/'Manuscript_Review_Report.md').write_text(report)
(O/'overlap_results.json').write_text(json.dumps(comparison,indent=2))
with zipfile.ZipFile(O/'Review_Evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in ['model_card.txt','dataset_card.txt','trocr_abstract.txt','overlap_results.json','audit.py','Manuscript_Review_Report.md']:z.write(O/n,n)
 z.write('/private/tmp/ocr2-live/reports/corrected_metrics.json','corrected_metrics.json')
with zipfile.ZipFile(O/'IEEE_Paper_Source.zip','a',zipfile.ZIP_DEFLATED) as z:z.write(O/'Manuscript_Review_Report.md','Manuscript_Review_Report.md')
print(json.dumps({'pages':len(r.pages),'metric_checks':len(required),'seven_word_matches':comparison,'authors':'verified'}))
